from pathlib import Path
import shutil,sys
root=Path(sys.argv[1]); here=Path(__file__).parent
java=root/'app/src/main/java/au/com/roningroup/patrollink'

def repl(path,old,new,count=1):
    s=path.read_text()
    if s.count(old)<count: raise SystemExit(f'MISSING in {path}: {old[:120]!r}')
    path.write_text(s.replace(old,new,count))

# Version + new classes
repl(root/'app/build.gradle','versionCode 139','versionCode 141')
repl(root/'app/build.gradle',"versionName '1.1.29'","versionName '1.1.31'")
for name in ['SilvertrackerLoginStore.java','SilvertrackerAutoLogin.java','FleetRelay.java','FleetUi.java','AppUpdateManager.java']:
    shutil.copyfile(here/name,java/name)

# Manifest: updater install handoff remains system-confirmed.
manifest=root/'app/src/main/AndroidManifest.xml'
repl(manifest,'    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
     '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />')

# Local GPS also publishes the same accepted fix to fleet when this device is an on-duty patrol.
gps=java/'LocalGpsService.java'
repl(gps,'        prefs(LocalGpsService.this).edit().putLong("heartbeat",System.currentTimeMillis()).apply();',
     '        prefs(LocalGpsService.this).edit().putLong("heartbeat",System.currentTimeMillis()).apply();\n        FleetRelay.publishLatest(LocalGpsService.this);')
repl(gps,'            .putBoolean("mock",fix.isFromMockProvider()).putString("status","GPS position received.").apply();\n        return true;',
     '            .putBoolean("mock",fix.isFromMockProvider()).putString("status","GPS position received.").apply();\n        FleetRelay.onLocalFix(c,fix);\n        return true;')

# Engine: secure opt-in remembered login.
engine=java/'PatrolEngine.java'
repl(engine,'    public final VoiceManager voices;','    public final VoiceManager voices;\n    public final SilvertrackerLoginStore loginStore;\n    private final SilvertrackerAutoLogin autoLogin;')
repl(engine,'        this.prefs = context.getSharedPreferences("patrol_settings", Context.MODE_PRIVATE);\n        this.voices = new VoiceManager(this.context, this.prefs);',
     '        this.prefs = context.getSharedPreferences("patrol_settings", Context.MODE_PRIVATE);\n        this.loginStore = new SilvertrackerLoginStore(this.context,this.prefs);\n        this.autoLogin = new SilvertrackerAutoLogin(this.loginStore);\n        this.voices = new VoiceManager(this.context, this.prefs);')
repl(engine,'        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);',
     '        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);\n        web.addJavascriptInterface(autoLogin.bridge(),"RoninSilverLogin");')
old='''                if (!monitorPage(url)) {
                    refreshActive = false;
                    status("SIGN_IN_REQUIRED", "Silvertracker is not on Issue Monitor. Open Silvertracker to complete sign-in once.");
                    nextCheckElapsed = SystemClock.elapsedRealtime() + INTERVAL;
                    return;
                }
                signedMonitorUrl = withoutRefreshNonce(url);'''
new='''                if (!monitorPage(url)) {
                    refreshActive = false;
                    if(autoLogin.onLoginPage(view,url))
                        status("AUTO_LOGIN", "Silvertracker session expired. Re-authenticating securely on this device…");
                    else
                        status("SIGN_IN_REQUIRED", loginStore.remember() && !loginStore.has()
                            ? "Remember login is enabled. Sign in once in Silvertracker; Patrol Link will securely remember this device's login."
                            : "Silvertracker is not on Issue Monitor. Open Silvertracker to complete sign-in once.");
                    nextCheckElapsed = SystemClock.elapsedRealtime() + INTERVAL;
                    return;
                }
                autoLogin.monitorReached();
                signedMonitorUrl = withoutRefreshNonce(url);'''
repl(engine,old,new)
# Public UI helpers.
insert='''    public boolean rememberSilvertrackerLogin(){ return loginStore.remember(); }
    public boolean hasRememberedSilvertrackerLogin(){ return loginStore.has(); }
    public void setRememberSilvertrackerLogin(boolean enabled){
        loginStore.setRemember(enabled);
        if(enabled && web!=null && trusted(web.getUrl()) && !monitorPage(web.getUrl())) autoLogin.onLoginPage(web,web.getUrl());
        notifyChanged();
    }
'''
repl(engine,'    public List<String> guards() {',insert+'    public List<String> guards() {')
repl(engine,'        prefs.edit().remove("last_live_read_at").apply();',
     '        prefs.edit().remove("last_live_read_at").apply();\n        loginStore.clear();')
repl(engine,'                "\\nLast refresh failure: " + lastRefreshFailure + "\\n" + voices.diagnostics() +',
     '                "\\nRemember Silvertracker login: " + loginStore.remember() + " · stored credentials: " + loginStore.has() +\n                "\\nFleet role: " + FleetRelay.label(context) + " · on duty: " + FleetRelay.onDuty(context) +\n                "\\nLast refresh failure: " + lastRefreshFailure + "\\n" + voices.diagnostics() +')

# Main activity: role-aware UI, fleet, secure-login toggle, and update channel.
main=java/'MainActivity.java'
repl(main,'    private LocalGpsUi gpsUi;\n    private TextView gpsSummary;',
     '    private LocalGpsUi gpsUi;\n    private FleetUi fleetUi;\n    private AppUpdateManager updateManager;\n    private TextView gpsSummary, fleetSummary;')
repl(main,'        gpsUi=new LocalGpsUi(this);',
     '        gpsUi=new LocalGpsUi(this);\n        fleetUi=new FleetUi(this,()->showDashboard());\n        updateManager=new AppUpdateManager(this);')
repl(main,'        if(getIntent().getBooleanExtra("open_patrol_gps",false))timer.post(()->gpsUi.show());',
     '        if(getIntent().getBooleanExtra("open_patrol_gps",false))timer.post(()->gpsUi.show());\n        updateManager.autoCheck();\n        fleetUi.maybeSetup();')
old='''        LinearLayout gps=card();gpsSummary=text(gpsUi.summary(),13,ACCENT,true);gps.addView(gpsSummary);gap(gps,8);
        gps.addView(text("Last GPS position of this phone · separate from Silvertracker activity",12,MUTED,false));gap(gps,8);
        gps.addView(button("Patrol GPS",false,()->gpsUi.show()));addCard(dashboard,gps);
        buttonRow(dashboard,button("Silvertracker",false,this::showBrowser),button("Guard settings",false,this::settings));
        addCard(dashboard,button("Speech controls",false,()->new SpeechSettingsUi(this,engine).show()));
        addCard(dashboard,new EntireScriptCopyUi(this,engine.voices));
        buttonRow(dashboard,button("Voice settings",false,this::voiceLibrary),button("Diagnostics",false,this::diagnostics));
        addCard(dashboard,dangerButton("Exit / sign out",this::confirmExit));'''
new='''        LinearLayout fleet=card();fleetSummary=text(fleetUi.summary(),13,ACCENT,true);fleet.addView(fleetSummary);gap(fleet,8);
        fleet.addView(text(fleetUi.master()?"Supervisor-only fleet view · Master never publishes patrol GPS":"Patrol GPS + preconfigured fleet relay · 15/30 second GPS",12,MUTED,false));gap(fleet,8);
        fleet.addView(button(fleetUi.master()?"Open Supervisor Fleet GPS":"Patrol duty / device role",false,fleetUi::open));addCard(dashboard,fleet);
        LinearLayout gps=card();gpsSummary=text(gpsUi.summary(),13,ACCENT,true);gps.addView(gpsSummary);gap(gps,8);
        gps.addView(text("Last GPS position of this phone · separate from Silvertracker activity",12,MUTED,false));gap(gps,8);
        gps.addView(button("Patrol GPS",false,()->gpsUi.show()));addCard(dashboard,gps);
        boolean userMode=fleetUi.configured()&&!fleetUi.master();
        if(userMode){
            buttonRow(dashboard,button("Silvertracker",false,this::showBrowser),button("Diagnostics",false,this::diagnostics));
        }else{
            buttonRow(dashboard,button("Silvertracker",false,this::showBrowser),button("Guard settings",false,this::settings));
            addCard(dashboard,button("Speech controls",false,()->new SpeechSettingsUi(this,engine).show()));
            addCard(dashboard,new EntireScriptCopyUi(this,engine.voices));
            buttonRow(dashboard,button("Voice settings",false,this::voiceLibrary),button("Diagnostics",false,this::diagnostics));
        }
        addCard(dashboard,button("Check for Patrol Link update",false,()->updateManager.check(true)));
        addCard(dashboard,dangerButton("Exit / sign out",this::confirmExit));'''
repl(main,old,new)
# Browser secure login toggle.
needle='''        buttonRow(toolbar,
            button("‹  Silvertracker page",false,()->engine.pageHistory(false)),
            button("Silvertracker page  ›",false,()->engine.pageHistory(true)));
        root.addView(toolbar);'''
replacement='''        buttonRow(toolbar,
            button("‹  Silvertracker page",false,()->engine.pageHistory(false)),
            button("Silvertracker page  ›",false,()->engine.pageHistory(true)));
        addCard(toolbar,button(engine.rememberSilvertrackerLogin()?"Remember Silvertracker login: ON":"Remember Silvertracker login: OFF",false,this::toggleRememberLogin));
        root.addView(toolbar);'''
repl(main,needle,replacement)
# New toggle method before browser tally.
method='''    private void toggleRememberLogin(){
        boolean next=!engine.rememberSilvertrackerLogin();
        engine.setRememberSilvertrackerLogin(next);
        if(next){
            new AlertDialog.Builder(this).setTitle("Remember Silvertracker login")
                .setMessage(engine.hasRememberedSilvertrackerLogin()
                    ? "Secure auto-login is enabled for this device."
                    : "Enabled. If Silvertracker is currently signed out, sign in normally once. Patrol Link will capture that submitted login and encrypt it with Android Keystore. It is never included in diagnostics.")
                .setPositiveButton("OK",null).show();
        }else toast("Remembered Silvertracker login cleared from this device.");
        showBrowser();
    }

'''
repl(main,'    private void refreshBrowserTally() {',method+'    private void refreshBrowserTally() {')
# Exit explicitly forgets remembered login, and patrol off-duty is broadcast.
repl(main,'                .setMessage("Exit is the only control that deliberately signs Patrol Link out. It stops monitoring and local GPS, clears the app\'s Silvertracker cookies/session and closes the app. Closing the app normally or swiping it from Recents does not clear the session.")',
     '                .setMessage("Exit is the only control that deliberately signs Patrol Link out. It stops monitoring and local GPS, marks a patrol off duty, clears the Silvertracker session and any remembered Silvertracker login, then closes the app. Closing the app normally or swiping it from Recents does not clear the session.")')
repl(main,'                    LocalGpsService.stop(this);',
     '                    FleetRelay.setDuty(this,false);\n                    LocalGpsService.stop(this);')
# Help reflects new behavior.
repl(main,'If Silvertracker itself invalidates the server-side session, Patrol Link stops the retry loop and shows Sign-in required. Open Silvertracker, sign in once, and monitoring resumes without clearing your cached activity.',
     'If Silvertracker invalidates the server-side session, Remember Silvertracker login can securely re-authenticate this device and return to Issue Monitor. Enable it on the Silvertracker screen and sign in normally once. If it is off, Patrol Link shows Sign-in required without clearing cached activity.')

# Basic source assertions.
assert 'versionCode 141' in (root/'app/build.gradle').read_text()
assert 'SilvertrackerAutoLogin' in engine.read_text()
assert 'FleetUi' in main.read_text()
assert 'REQUEST_INSTALL_PACKAGES' in manifest.read_text()
print('Applied Patrol Link v1.1.31: secure Silvertracker re-authentication, Master/User fleet UI, and remote update channel.')
