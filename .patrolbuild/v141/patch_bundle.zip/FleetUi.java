package au.com.roningroup.patrollink;

import android.app.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import java.util.*;

/** Role, duty and supervisor fleet UI. */
public final class FleetUi {
    private final Activity a;private final Runnable changed;
    public FleetUi(Activity a,Runnable changed){this.a=a;this.changed=changed;}
    public boolean configured(){return FleetRelay.configured(a);}public boolean master(){return FleetRelay.master(a);}
    public String summary(){if(!configured())return "Choose this phone's Patrol Link role";if(master())return "Master / Supervisor · fleet view";return "Patrol "+FleetRelay.patrol(a)+(FleetRelay.onDuty(a)?" · ON DUTY":" · Off duty")+" · "+FleetRelay.prefs(a).getString("gps_relay_status","Waiting for relay");}
    public void maybeSetup(){if(!configured())new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this::setup,450);}
    public void open(){if(!configured())setup();else if(master())fleet();else patrolControls();}
    public void setup(){
        LinearLayout box=new LinearLayout(a);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(40,18,40,4);Spinner mode=new Spinner(a),patrol=new Spinner(a);
        mode.setAdapter(new ArrayAdapter<String>(a,android.R.layout.simple_spinner_dropdown_item,new String[]{"Master / Supervisor","User / Patrol phone"}));
        patrol.setAdapter(new ArrayAdapter<String>(a,android.R.layout.simple_spinner_dropdown_item,new String[]{"Patrol 1","Patrol 2","Patrol 3"}));
        mode.setSelection(FleetRelay.master(a)?0:1);patrol.setSelection(Math.max(0,FleetRelay.patrol(a)-1));box.addView(label("DEVICE ROLE"));box.addView(mode);box.addView(label("PATROL NUMBER · USER ONLY"));box.addView(patrol);TextView note=label("Master is the supervisor-only phone and does not publish patrol GPS. User is one of Patrol 1, 2 or 3. The same APK is used on every phone.");box.addView(note);
        AlertDialog d=new AlertDialog.Builder(a).setTitle("Patrol device setup").setView(box).setPositiveButton("Save",null).setNegativeButton("Cancel",null).create();d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{boolean isMaster=mode.getSelectedItemPosition()==0;FleetRelay.configure(a,isMaster,patrol.getSelectedItemPosition()+1);d.dismiss();changed.run();if(!isMaster)patrolControls();}));d.show();
    }
    private TextView label(String s){TextView t=new TextView(a);t.setText(s);t.setPadding(0,12,0,12);return t;}
    public void patrolControls(){
        boolean duty=FleetRelay.onDuty(a);String msg="This device: Patrol "+FleetRelay.patrol(a)+"\n\n"+(duty?"This patrol is ON DUTY and visible to the Master device.":"Not transmitting as an active patrol.")+"\n\nPositions use the normal Patrol GPS foreground service and update the preconfigured fleet relay.";
        new AlertDialog.Builder(a).setTitle("Patrol GPS + fleet link").setMessage(msg).setPositiveButton(duty?"Go off duty":"Go on duty",(d,w)->{if(!duty){if(!LocalGpsService.hasPermission(a)){changed.run();return;}LocalGpsService.start(a);}FleetRelay.setDuty(a,!duty);if(!duty)FleetRelay.publishLatest(a);changed.run();}).setNeutralButton("Device setup",(d,w)->setup()).setNegativeButton("Close",null).show();
    }
    public void fleet(){loadFleet(null);}
    private void loadFleet(AlertDialog prior){if(prior!=null)prior.dismiss();final ProgressDialog p=ProgressDialog.show(a,"Supervisor Fleet GPS","Connecting to Patrol 1 / 2 / 3…",true,false);FleetRelay.load(a,(fleet,error)->{p.dismiss();StringBuilder s=new StringBuilder();if(error!=null)s.append(error).append("\n\n");for(int n=1;n<=3;n++){FleetRelay.Patrol x=fleet.get(n);s.append("PATROL ").append(n).append("\n");if(x==null)s.append("Waiting for relay\n\n");else{s.append(x.onDuty?x.state:"Off duty").append(" · ");if(x.time>0)s.append(age(x.age())).append(" ago");else s.append("time unknown");s.append("\n");if(x.lat!=0||x.lon!=0)s.append(String.format(java.util.Locale.US,"%.6f, %.6f · ±%.0fm",x.lat,x.lon,x.accuracy));s.append("\n");if(x.segments!=null&&x.segments.length()>0)s.append(x.segments.length()).append(" movement/history segments\n");s.append("\n");}}
            AlertDialog d=new AlertDialog.Builder(a).setTitle("Live fleet").setMessage(s.toString()).setPositiveButton("Refresh",null).setNeutralButton("Device setup",(q,w)->setup()).setNegativeButton("Close",null).create();d.setOnShowListener(q->d.getButton(-1).setOnClickListener(v->loadFleet(d)));d.show();});}
    private String age(long ms){long sec=ms/1000;if(sec<60)return sec+"s";long m=sec/60;if(m<60)return m+"m";return (m/60)+"h "+(m%60)+"m";}
}
