package au.com.roningroup.patrollink;

import android.os.*;
import android.webkit.*;
import org.json.JSONObject;

/** Captures only an opted-in manual Silvertracker form submit and replays it only on trusted Silvertracker HTTPS hosts. */
public final class SilvertrackerAutoLogin {
    private final SilvertrackerLoginStore store;
    private long lastAttempt;
    private int attempts;
    public SilvertrackerAutoLogin(SilvertrackerLoginStore store){this.store=store;}
    public Object bridge(){return new Bridge();}
    public boolean onLoginPage(WebView web,String url){
        if(web==null||!PatrolEngine.trusted(url)||PatrolEngine.monitorPage(url))return false;
        injectCapture(web);
        String[] c=store.get();if(c==null)return false;
        long now=SystemClock.elapsedRealtime();if(now-lastAttempt<4500||attempts>=3)return false;
        lastAttempt=now;attempts++;
        String u=JSONObject.quote(c[0]),p=JSONObject.quote(c[1]);
        String js="(function(){try{var pw=document.querySelector('input[type=password]');if(!pw)return 'no-password';var f=pw.form||document.querySelector('form');if(!f)return 'no-form';var ins=Array.prototype.slice.call(f.querySelectorAll('input'));var user=null;for(var i=0;i<ins.length;i++){var x=ins[i],t=(x.type||'text').toLowerCase();if(x!==pw&&(t==='text'||t==='email'||t==='tel')){user=x;break;}}if(!user)return 'no-user';function set(x,v){var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');if(d&&d.set)d.set.call(x,v);else x.value=v;x.dispatchEvent(new Event('input',{bubbles:true}));x.dispatchEvent(new Event('change',{bubbles:true}));}set(user,"+u+");set(pw,"+p+");setTimeout(function(){var b=f.querySelector('button[type=submit],input[type=submit]');if(f.requestSubmit)f.requestSubmit(b||undefined);else if(b)b.click();else f.submit();},180);return 'submitted';}catch(e){return 'error';}})();";
        web.evaluateJavascript(js,null);return true;
    }
    public void monitorReached(){attempts=0;lastAttempt=0;}
    private void injectCapture(WebView web){
        if(!store.remember())return;
        String js="(function(){try{if(window.__roninRememberHook)return;window.__roninRememberHook=1;document.addEventListener('submit',function(ev){try{var f=ev.target;if(!f||!f.querySelector)return;var pw=f.querySelector('input[type=password]');if(!pw||!pw.value)return;var ins=Array.prototype.slice.call(f.querySelectorAll('input'));var user=null;for(var i=0;i<ins.length;i++){var x=ins[i],t=(x.type||'text').toLowerCase();if(x!==pw&&(t==='text'||t==='email'||t==='tel')&&x.value){user=x;break;}}if(user&&window.RoninSilverLogin)window.RoninSilverLogin.capture(user.value,pw.value);}catch(e){}},true);}catch(e){}})();";
        web.evaluateJavascript(js,null);
    }
    public final class Bridge {
        @JavascriptInterface public void capture(String user,String pass){store.save(user,pass);}
    }
}
