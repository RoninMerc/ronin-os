from pathlib import Path
import sys, shutil
root=Path(sys.argv[1]); java=root/'app/src/main/java/au/com/roningroup/patrollink'; here=Path(__file__).parent

def rep(path,old,new,count=1):
 s=path.read_text(); assert old in s,(path,old[:120]); path.write_text(s.replace(old,new,count))

rep(root/'app/build.gradle','versionCode 142','versionCode 143')
rep(root/'app/build.gradle',"versionName '1.1.32'","versionName '1.1.33'")
shutil.copyfile(here/'CheckpointProximityUi.java',java/'CheckpointProximityUi.java')
main=java/'MainActivity.java'
rep(main,'    private LocalGpsUi gpsUi;','    private LocalGpsUi gpsUi;\n    private CheckpointProximityUi checkpointUi;')
rep(main,'        gpsUi=new LocalGpsUi(this);','        gpsUi=new LocalGpsUi(this);\n        checkpointUi=new CheckpointProximityUi(this);')
# Add checkpoint proximity card immediately after the GPS card.
needle='''        gps.addView(button("Patrol GPS",false,()->gpsUi.show()));addCard(dashboard,gps);'''
repl=needle+'''\n        View proximity=checkpointUi.dashboardCard();addCard(dashboard,proximity);'''
rep(main,needle,repl)
rep(main,'        if(gpsSummary!=null)gpsSummary.setText(gpsUi.summary());','        if(gpsSummary!=null)gpsSummary.setText(gpsUi.summary());\n        if(checkpointUi!=null)checkpointUi.tick();')
print('Applied v1.1.33 GPS checkpoint proximity and supervisor registration.')
