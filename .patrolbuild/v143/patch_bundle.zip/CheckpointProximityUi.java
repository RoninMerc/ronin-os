package au.com.roningroup.patrollink;

import android.app.*;
import android.content.*;
import android.graphics.Typeface;
import android.location.Location;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** GPS proximity assistant for physical Silvertracker QR checkpoints. Never records a Silvertracker scan. */
public final class CheckpointProximityUi {
    private static final String PREFS="patrol_checkpoint_proximity_v1", KEY="checkpoints_json";
    private static final float DEFAULT_TRIGGER=70f, CLEAR_RADIUS=140f;
    private final Activity activity;
    private final SharedPreferences prefs;
    private LinearLayout card;
    private TextView title, distance, hint;
    private Button complete;
    private String activeId="";
    private long lapEpoch;
    private final ArrayList<Checkpoint> checkpoints=new ArrayList<>();

    static final class Checkpoint {
        String id,name; double lat,lon; float radius;
        Checkpoint(String i,String n,double a,double o,float r){id=i;name=n;lat=a;lon=o;radius=r;}
    }

    public CheckpointProximityUi(Activity a){activity=a;prefs=a.getSharedPreferences(PREFS,Context.MODE_PRIVATE);load();lapEpoch=prefs.getLong("lap_epoch",0);}
    private int dp(float x){return Math.round(x*activity.getResources().getDisplayMetrics().density);}
    private TextView text(String s,int sp,int colour,boolean bold){TextView t=new TextView(activity);t.setText(s);t.setTextSize(sp);t.setTextColor(colour);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));t.setIncludeFontPadding(false);return t;}
    private Button button(String s,Runnable r){Button b=new Button(activity);b.setText(s);b.setAllCaps(false);b.setMinHeight(dp(54));b.setOnClickListener(v->r.run());return b;}
    public View dashboardCard(){
        card=new LinearLayout(activity);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(16),dp(18),dp(16));
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setColor(0xff121d27);bg.setCornerRadius(dp(16));bg.setStroke(dp(1),0xff263746);card.setBackground(bg);
        title=text("CHECKPOINT PROXIMITY",12,0xff70d7c4,true);card.addView(title);
        Space s=new Space(activity);card.addView(s,new LinearLayout.LayoutParams(1,dp(9)));
        distance=text("No mapped checkpoint nearby",22,0xffeef4f9,true);card.addView(distance);
        Space s2=new Space(activity);card.addView(s2,new LinearLayout.LayoutParams(1,dp(7)));
        hint=text("Supervisor can register checkpoint locations from the checkpoint manager.",12,0xff9daebb,false);card.addView(hint);
        complete=button("Complete",this::completeActive);complete.setVisibility(View.GONE);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(56));lp.topMargin=dp(12);card.addView(complete,lp);
        card.setOnClickListener(v->showManager()); tick(); return card;
    }
    public void tick(){
        if(card==null)return;
        long fix=LocalGpsService.prefs(activity).getLong("fix_time",0); long age=LocalGpsService.fixAgeSeconds(activity);
        if(fix==0||age<0||age>90){showNone(age>90?"GPS position is stale":"Waiting for current GPS position");return;}
        SharedPreferences gp=LocalGpsService.prefs(activity);double lat=Double.longBitsToDouble(gp.getLong("lat",0)),lon=Double.longBitsToDouble(gp.getLong("lon",0));
        Checkpoint best=null;float bestDist=Float.MAX_VALUE;
        for(Checkpoint c:checkpoints){if(completed(c.id))continue;float d=distance(lat,lon,c.lat,c.lon);if(d<=Math.max(c.radius,DEFAULT_TRIGGER)&&d<bestDist){best=c;bestDist=d;}}
        if(best==null){
            if(!activeId.isEmpty()){
                Checkpoint old=find(activeId);if(old!=null&&distance(lat,lon,old.lat,old.lon)<CLEAR_RADIUS)return;
            }
            activeId="";showNone(checkpoints.isEmpty()?"No checkpoint locations registered":"No outstanding checkpoint nearby");return;
        }
        activeId=best.id;float bearing=bearing(lat,lon,best.lat,best.lon);String arrow=arrow(bearing);String reached=bestDist<=25?"CHECKPOINT REACHED":"CHECKPOINT NEARBY";
        title.setText(reached);distance.setText(best.name+"   "+arrow+"  "+Math.round(bestDist)+" m");hint.setText("Scan the physical SilverTrack QR code, then tap Complete. GPS proximity alone never records a scan.");complete.setVisibility(View.VISIBLE);
    }
    private void showNone(String s){title.setText("CHECKPOINT PROXIMITY");distance.setText(s);hint.setText(supervisor()?"Tap here to register or manage checkpoint locations.":"Mapped checkpoints will appear automatically as you approach them.");complete.setVisibility(View.GONE);}
    private static float distance(double a,double o,double b,double p){float[] r=new float[2];Location.distanceBetween(a,o,b,p,r);return r[0];}
    private static float bearing(double a,double o,double b,double p){float[] r=new float[2];Location.distanceBetween(a,o,b,p,r);return (r[1]+360f)%360f;}
    private static String arrow(float b){if(b<22.5||b>=337.5)return "↑";if(b<67.5)return "↗";if(b<112.5)return "→";if(b<157.5)return "↘";if(b<202.5)return "↓";if(b<247.5)return "↙";if(b<292.5)return "←";return "↖";}
    private boolean supervisor(){return "master".equalsIgnoreCase(activity.getSharedPreferences("patrol_settings",0).getString("device_mode","user"));}
    private boolean completed(String id){return prefs.getLong("done_"+id,0)>=lapEpoch&&lapEpoch>0;}
    private void completeActive(){if(activeId.isEmpty())return;prefs.edit().putLong("done_"+activeId,System.currentTimeMillis()).apply();activeId="";tick();Toast.makeText(activity,"Checkpoint cleared from this Patrol Link lap.",Toast.LENGTH_SHORT).show();}
    public void newLap(){lapEpoch=System.currentTimeMillis();SharedPreferences.Editor e=prefs.edit().putLong("lap_epoch",lapEpoch);for(Checkpoint c:checkpoints)e.remove("done_"+c.id);e.apply();activeId="";tick();Toast.makeText(activity,"Checkpoint proximity reset for a new lap.",Toast.LENGTH_SHORT).show();}
    private Checkpoint find(String id){for(Checkpoint c:checkpoints)if(c.id.equals(id))return c;return null;}
    private void load(){checkpoints.clear();try{JSONArray a=new JSONArray(prefs.getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)checkpoints.add(new Checkpoint(o.optString("id"),o.optString("name"),o.optDouble("lat"),o.optDouble("lon"),(float)o.optDouble("radius",DEFAULT_TRIGGER)));}}catch(Exception ignored){}}
    private void save(){JSONArray a=new JSONArray();try{for(Checkpoint c:checkpoints){JSONObject o=new JSONObject();o.put("id",c.id);o.put("name",c.name);o.put("lat",c.lat);o.put("lon",c.lon);o.put("radius",c.radius);a.put(o);}}catch(Exception ignored){}prefs.edit().putString(KEY,a.toString()).apply();}
    public void showManager(){
        LinearLayout form=new LinearLayout(activity);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),dp(8));
        TextView info=text(supervisor()?"SUPERVISOR CHECKPOINT MANAGER":"CHECKPOINT STATUS",12,0xff70d7c4,true);form.addView(info);
        TextView note=text(supervisor()?"Drive to a checkpoint, select its name and tap Register checkpoint location. Patrol Link saves this phone's current GPS fix. This does not scan or complete the SilverTrack checkpoint.":"Checkpoint coordinates are supervisor-managed. Nearby mapped checkpoints appear automatically on the dashboard.",12,0xff9daebb,false);note.setPadding(0,dp(8),0,dp(12));form.addView(note);
        if(checkpoints.isEmpty())form.addView(text("No mapped checkpoint locations yet.",14,0xffeef4f9,false));
        for(Checkpoint c:new ArrayList<>(checkpoints)){LinearLayout row=new LinearLayout(activity);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(0,dp(6),0,dp(10));row.addView(text(c.name,16,0xffeef4f9,true));row.addView(text(String.format(Locale.ROOT,"%.6f, %.6f · trigger %.0f m",c.lat,c.lon,c.radius),12,0xff9daebb,false));if(supervisor())row.addView(button("Update location to my current GPS",()->register(c.name,c.id)));form.addView(row);}
        if(supervisor()){
            Spinner names=new Spinner(activity);ArrayList<String> options=new ArrayList<>(Arrays.asList("Ceil 001","Slipstream 001","Boambillee 001","General Patrol - Christina BC","General Patrol - Solo BC","Serenade 001","Eolo BC 001","General Patrol - Bobsled BC","Elusive BC 001","Custom checkpoint…"));ArrayAdapter<String> ad=new ArrayAdapter<>(activity,android.R.layout.simple_spinner_item,options);ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);names.setAdapter(ad);form.addView(names);
            EditText custom=new EditText(activity);custom.setHint("Custom checkpoint name");custom.setTextColor(0xffeef4f9);custom.setHintTextColor(0xff6f808c);form.addView(custom);
            form.addView(button("Register checkpoint location",()->{String n=String.valueOf(names.getSelectedItem());if(n.startsWith("Custom"))n=custom.getText().toString().trim();if(n.isEmpty()){Toast.makeText(activity,"Enter a checkpoint name.",Toast.LENGTH_SHORT).show();return;}register(n,slug(n));}));
            form.addView(button("Start new patrol lap",this::newLap));
        }
        ScrollView scroll=new ScrollView(activity);scroll.addView(form);new AlertDialog.Builder(activity).setTitle("Checkpoint proximity").setView(scroll).setPositiveButton("Close",null).show();
    }
    private static String slug(String s){return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+","-").replaceAll("(^-|-$)","");}
    private void register(String name,String id){
        if(!supervisor()){Toast.makeText(activity,"Supervisor mode is required.",Toast.LENGTH_SHORT).show();return;}
        SharedPreferences gp=LocalGpsService.prefs(activity);long t=gp.getLong("fix_time",0);long age=LocalGpsService.fixAgeSeconds(activity);if(t==0||age<0||age>30){Toast.makeText(activity,"Need a current GPS fix less than 30 seconds old.",Toast.LENGTH_LONG).show();return;}
        if(!LocalGpsService.precise(activity)){Toast.makeText(activity,"Enable Precise location before registering a checkpoint.",Toast.LENGTH_LONG).show();return;}
        double lat=Double.longBitsToDouble(gp.getLong("lat",0)),lon=Double.longBitsToDouble(gp.getLong("lon",0));Checkpoint c=find(id);if(c==null){c=new Checkpoint(id,name,lat,lon,DEFAULT_TRIGGER);checkpoints.add(c);}else{c.name=name;c.lat=lat;c.lon=lon;}
        save();Toast.makeText(activity,name+" location registered.",Toast.LENGTH_SHORT).show();tick();
    }
}
