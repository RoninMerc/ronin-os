from pathlib import Path
import sys, shutil
root=Path(sys.argv[1]); src=Path(__file__).parent
java=root/'app/src/main/java/au/com/roningroup/patrollink'
for n in ['FeatherlessSecretStore.java','FeatherlessVoice.java','FeatherlessVoiceUi.java']:
    shutil.copyfile(src/n,java/n)

def rep(path,old,new,count=1):
    s=path.read_text(); assert old in s,(path,old[:120]); path.write_text(s.replace(old,new,count))

# v1.1.31 -> v1.1.32
rep(root/'app/build.gradle','versionCode 141','versionCode 142')
rep(root/'app/build.gradle',"versionName '1.1.31'","versionName '1.1.32'")

engine=java/'PatrolEngine.java'
rep(engine,'    public final VoiceManager voices;','    public final VoiceManager voices;\n    public final FeatherlessVoice featherlessVoice;')
rep(engine,'        this.voices = new VoiceManager(this.context, this.prefs);','        this.voices = new VoiceManager(this.context, this.prefs);\n        this.featherlessVoice = new FeatherlessVoice(this.context, this.prefs);')
rep(engine,'                if (running && prefs.getBoolean("voice", true) && !welcomeSpokenThisSession && voices.welcome()) welcomeSpokenThisSession = true;\n                if (running && prefs.getBoolean("voice", true)) for (Observation o : announce) voices.speak(o);',
'''                if (running && prefs.getBoolean("voice", true) && !welcomeSpokenThisSession) {
                    if (featherlessVoice.selected()) { featherlessVoice.speak("Good evening, Tristan. Let's have a good shift."); welcomeSpokenThisSession=true; }
                    else if (voices.welcome()) welcomeSpokenThisSession=true;
                }
                if (running && prefs.getBoolean("voice", true)) for (Observation o : announce) {
                    if (featherlessVoice.selected()) featherlessVoice.speak(voices.speechSettings.format(o)); else voices.speak(o);
                }''')
rep(engine,'        voices.stop();','        voices.stop();\n        featherlessVoice.stop();')
rep(engine,'                "\\nLast refresh failure: " + lastRefreshFailure + "\\n" + voices.diagnostics() +',
'                "\\nLast refresh failure: " + lastRefreshFailure + "\\n" + voices.diagnostics() + "\\n" + featherlessVoice.diagnostics() +')

main=java/'MainActivity.java'
# Add visible cloud control beside existing voice tools. The exact/local library remains unchanged.
needle='        addCard(dashboard,button("Speech controls",false,()->new SpeechSettingsUi(this,engine).show()));'
rep(main,needle,needle+'\n        addCard(dashboard,button("Featherless AI voice",false,()->new FeatherlessVoiceUi(this,engine.featherlessVoice).show()));')
# Also expose inside Voice settings for users who naturally look there.
needle2='        form.addView(text(engine.voices.status(),12,engine.voices.ready()?ACCENT:AMBER,true));gap(form,8);'
rep(main,needle2,needle2+'\n        form.addView(text("Output mode · "+(engine.featherlessVoice.selected()?"Featherless AI cloud TTS":"Exact WAV / Tiff local"),12,ACCENT,true));gap(form,8);\n        addCard(form,button("Configure Featherless AI voice",false,()->new FeatherlessVoiceUi(this,engine.featherlessVoice).show()));')
# Main dashboard voice status should say which engine is active.
old='voiceStatusText.setText("Voice · "+(engine.prefs.getBoolean("voice",true)?engine.voices.status():"Muted")); voiceStatusText.setTextColor(engine.voices.error().isEmpty()?MUTED:AMBER);'
if old in main.read_text():
    rep(main,old,'voiceStatusText.setText("Voice · "+(engine.prefs.getBoolean("voice",true)?(engine.featherlessVoice.selected()?engine.featherlessVoice.status():engine.voices.status()):"Muted")); voiceStatusText.setTextColor((engine.featherlessVoice.selected()?engine.featherlessVoice.error():engine.voices.error()).isEmpty()?MUTED:AMBER);')
print('Applied Patrol Link v1.1.32 Featherless voice patch')
