package au.com.roningroup.patrollink;

import android.content.*;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Android Keystore-backed storage for the Featherless API key. */
public final class FeatherlessSecretStore {
    private static final String ALIAS="patrol_link_featherless_api_v1";
    private static final String PREF="featherless_api_cipher_v1";
    private final SharedPreferences prefs;
    public FeatherlessSecretStore(Context context, SharedPreferences prefs){ this.prefs=prefs; }
    private SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if(ks.containsAlias(ALIAS)) return (SecretKey)ks.getKey(ALIAS,null);
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build());
        return kg.generateKey();
    }
    public void put(String value) throws Exception {
        if(value==null||value.trim().isEmpty()){ clear(); return; }
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key());
        byte[] cipher=c.doFinal(value.trim().getBytes(StandardCharsets.UTF_8)); byte[] iv=c.getIV();
        byte[] merged=new byte[1+iv.length+cipher.length]; merged[0]=(byte)iv.length;
        System.arraycopy(iv,0,merged,1,iv.length); System.arraycopy(cipher,0,merged,1+iv.length,cipher.length);
        prefs.edit().putString(PREF,Base64.encodeToString(merged,Base64.NO_WRAP)).apply();
    }
    public String get(){
        try{
            String stored=prefs.getString(PREF,""); if(stored.isEmpty())return "";
            byte[] merged=Base64.decode(stored,Base64.NO_WRAP); int n=merged[0]&0xff;
            if(n<8||n>32||merged.length<=1+n)return "";
            byte[] iv=new byte[n], data=new byte[merged.length-1-n];
            System.arraycopy(merged,1,iv,0,n); System.arraycopy(merged,1+n,data,0,data.length);
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
            return new String(c.doFinal(data),StandardCharsets.UTF_8);
        }catch(Exception e){return "";}
    }
    public boolean has(){return !get().isEmpty();}
    public void clear(){prefs.edit().remove(PREF).apply();try{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(ALIAS))ks.deleteEntry(ALIAS);}catch(Exception ignored){}}
}
