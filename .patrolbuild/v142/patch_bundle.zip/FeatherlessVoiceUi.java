package au.com.roningroup.patrollink;

import android.app.*;import android.content.*;import android.graphics.Typeface;import android.text.InputType;import android.view.*;import android.widget.*;

/** Compact Featherless voice configuration. */
public final class FeatherlessVoiceUi {
    private static final int WHITE=0xffeef4f9,MUTED=0xff9daebb,ACCENT=0xff70d7c4;
    private final Activity a;private final FeatherlessVoice voice;
    public FeatherlessVoiceUi(Activity a,FeatherlessVoice voice){this.a=a;this.voice=voice;}
    private int dp(float n){return Math.round(n*a.getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(a);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));t.setPadding(0,dp(4),0,dp(4));return t;}
    private EditText input(String value,String hint,int type){EditText e=new EditText(a);e.setText(value);e.setHint(hint);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setSingleLine(true);e.setInputType(type);return e;}
    public void show(){
        LinearLayout f=new LinearLayout(a);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(22),dp(8),dp(22),dp(8));
        f.addView(text("VOICE PROVIDER",12,MUTED,true));Spinner provider=new Spinner(a);String[] options={"Exact WAV / Tiff (local)","Featherless AI (cloud TTS)"};ArrayAdapter<String> ad=new ArrayAdapter<>(a,android.R.layout.simple_spinner_item,options);ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);provider.setAdapter(ad);provider.setSelection(voice.selected()?1:0);f.addView(provider);
        f.addView(text("Featherless API key",12,MUTED,true));EditText key=input(voice.hasKey()?"••••••••":"","Bearer API key",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);f.addView(key);
        f.addView(text("Speech endpoint",12,MUTED,true));EditText endpoint=input(voice.endpoint(),FeatherlessVoice.DEFAULT_ENDPOINT,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);f.addView(endpoint);
        f.addView(text("Exact speech model ID",12,MUTED,true));EditText model=input(voice.model(),FeatherlessVoice.DEFAULT_MODEL,InputType.TYPE_CLASS_TEXT);f.addView(model);
        f.addView(text("Exact voice ID",12,MUTED,true));EditText voiceId=input(voice.voice(),FeatherlessVoice.DEFAULT_VOICE,InputType.TYPE_CLASS_TEXT);f.addView(voiceId);
        f.addView(text("Voice speed",12,MUTED,true));EditText speed=input(Float.toString(voice.speed()),"1.0",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);f.addView(speed);
        f.addView(text("Default: hexgrad/Kokoro-82M + bf_isabella. The API key is encrypted with Android Keystore. In Featherless mode Patrol Link sends only the announcement text needed for speech. If cloud speech fails, Patrol Link reports the error; it does not silently switch to a different voice.",12,MUTED,false));
        LinearLayout actions=new LinearLayout(a);actions.setOrientation(LinearLayout.HORIZONTAL);Button discover=new Button(a);discover.setText("Discover voices");Button test=new Button(a);test.setText("Test voice");actions.addView(discover,new LinearLayout.LayoutParams(0,dp(52),1));actions.addView(test,new LinearLayout.LayoutParams(0,dp(52),1));f.addView(actions);
        TextView status=text(voice.status(),12,ACCENT,false);f.addView(status);
        ScrollView scroll=new ScrollView(a);scroll.addView(f);
        AlertDialog d=new AlertDialog.Builder(a).setTitle("Featherless AI voice").setView(scroll).setPositiveButton("Save",null).setNeutralButton("Clear key",null).setNegativeButton("Close",null).create();
        d.setOnShowListener(x->{
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{float sp=Float.parseFloat(speed.getText().toString().trim());voice.save(endpoint.getText().toString(),model.getText().toString(),voiceId.getText().toString(),sp,key.getText().toString(),provider.getSelectedItemPosition()==1);status.setText(voice.status());Toast.makeText(a,"Voice settings saved",Toast.LENGTH_SHORT).show();}catch(Exception e){status.setText(e.getMessage());}});
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{voice.clearKey();key.setText("");status.setText(voice.status());});
            discover.setOnClickListener(v->{status.setText("Loading Featherless voices…");voice.discoverVoices((ok,msg)->new AlertDialog.Builder(a).setTitle(ok?"Featherless voices":"Voice discovery failed").setMessage(msg).setPositiveButton("OK",null).show());});
            test.setOnClickListener(v->{try{float sp=Float.parseFloat(speed.getText().toString().trim());voice.save(endpoint.getText().toString(),model.getText().toString(),voiceId.getText().toString(),sp,key.getText().toString(),true);status.setText("Testing Featherless voice…");voice.test((ok,msg)->{status.setText(ok?"Test passed":"Test failed: "+msg);Toast.makeText(a,msg,Toast.LENGTH_LONG).show();});}catch(Exception e){status.setText(e.getMessage());}});
        });d.show();
    }
}
